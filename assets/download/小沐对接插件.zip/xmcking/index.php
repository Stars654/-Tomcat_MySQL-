<?php

include ('../confing/common.php');
include ('./config.php');
// 处理用户提交的表单，保存 $hid 的值
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["hid"])) {
    $hid = $_POST["hid"];
    // 保存到文件中，或者数据库中，以便在下次访问时保持值不变
    // 这里简单地将值保存到文件中
    file_put_contents("config.php", "<?php\n\$hid = $hid;\n?>");
} else {
    // 如果没有提交表单，尝试从 config.php 文件中获取 $hid 的值
    include("config.php");
}
// if ($islogin != 1) {
//     exit("<script language='javascript'>window.location.href='/login';</script>");
// }
// if ($userrow['uid'] != 1) {
//     exit("<script language='javascript'>window.location.href='/login';</script>");
// }

?>
<!DOCTYPE html>
<html lang="zh">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="keywords" content="LightYear,LightYearAdmin,光年,后台模板,后台管理系统,光年HTML模板">
    <meta name="description" content="Light Year Admin V5是一个基于Bootstrap v5.1.3的后台管理系统的HTML模板。">
    <meta name="author" content="yinq">
    <title>快速对接 - M平台专属</title>
    <link rel="shortcut icon" type="image/x-icon" href="favicon.ico">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <link rel="stylesheet" type="text/css" href="LightYear/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="LightYear/css/style.min.css">
    <link rel="stylesheet" type="text/css" href="LightYear/css/element.css">
</head>
<div class="container">
<body style="background-color: #f5f5f5;">
    <!--页面主要内容-->
    <div class="container-fluid">
        <div class="row" id="dock">
            <div class="col-md-4">
                <div class="card mb-3">
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">货源ID</label>
                            <form method="POST">
                                <select class="form-select" v-model="hid" name="hid">
                                    <option value="">请选择货源ID</option>
                                    <?php
                                    $query = $DB->query("SELECT hid, name FROM qingka_wangke_huoyuan");
                                    while ($row = $DB->fetch($query)) {
                                    ?>
                                        <option value="<?= $row['hid'] ?>"><?= $row['hid'] ?> - <?= $row['name'] ?></option>
                                    <?php } ?>
                                </select>
                                <br>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary" @click="getClassAndCate" >保存</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">上架分类</label>
                            <select class="form-select" v-model="cateId">
                                <option value="">请选择分类</option>
                                <?php
                                $a = $DB->query("select id,name from qingka_wangke_fenlei ORDER BY `sort` ASC");
                                while ($rs = $DB->fetch($a)) {
                                ?>
                                    <option :value="<?= $rs['id'] ?>">
                                        <?= $rs['name'] ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">加价方式</label>
                            <select class="form-select" v-model="addMode">
                                <option value="1">加法</option>
                                <option value="2">乘法</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">加价系数</label>
                            <input type="text" v-model="addCode" class="form-control" placeholder="请输入加价系数">
                        </div>
                        <div class="d-grid">
                            <button class="btn btn-primary" type="button" @click="handleAdd">确认上架</button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-8">
                <div class="card">
                    <div class="alert alert-primary" role="alert" style="background-color: #007BFF; color: yellow;">
                        先保存货源，后上架商品
                    </div>
                    <div class="card-header">
                        <div style="display: flex;justify-content: space-between;align-items: center">
                            <div class="card-title">总计 <font style="color: #007bff;font-weight: bold;">{{ showClass?.length || 0 }}</font> 门课程</div>
                            <div style="display: flex;align-items: center">
                                <input type="text" v-model="keywords" class="form-control" placeholder="请输入关键词">
                                <select class="form-select ms-2" style="width: 150px;" @change="handleCateChange" v-model="activeCateId">
                                    <option value="">全部课程</option>
                                    <option v-for="item in dockCate" :key="item.id" :value="item.id">{{ item.name }}</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="card-body" style="padding: 0">
                        <el-table ref="tableRef" :data="showClass" height="630" style="width: 100%" @selection-change="handleSelectionChange">
                            <el-table-column type="selection" width="55" align="center"></el-table-column>
                            <el-table-column label="课程ID" width="80">
                                <template #default="scope">{{ scope.row.cid }}</template>
                            </el-table-column>
                            <el-table-column label="课程名称">
                                <template #default="scope">{{ scope.row.name }}</template>
                            </el-table-column>
                            <el-table-column label="课程价格">
                                <template #default="scope">{{ scope.row.price | filterPrice }}</template>
                            </el-table-column>
                            <el-table-column label="是否上架">
                                <template #default="scope">
    <span :class="['btn', 'btn-xs', scope.row.status === 1 ? 'btn-success' : (scope.row.status === -1 ? 'btn-danger' : '')]">
        <i v-if="scope.row.status === 1" class="el-icon-check"></i>
        <i v-else-if="scope.row.status === -1" class="el-icon-close"></i>
        {{ scope.row.status === 1 ? '已上架' : (scope.row.status === -1 ? '未上架' : '') }}
    </span>
</template>

                            </el-table-column>
                            <el-table-column prop="price" label="对接价格" />

                        </el-table>
                    </div>
                </div>
            </div>

        </div>

    </div>
     </div>
    <!--End 页面主要内容-->

    <script type="text/javascript" src="LightYear/js/jquery.min.js"></script>
    <script type="text/javascript" src="LightYear/js/bootstrap.min.js"></script>
    <!-- 三件套 -->
    <script type="text/javascript" src="LightYear/js/vue.min.js"></script>
    <script type="text/javascript" src="LightYear/js/vue-resource.min.js"></script>
    <script type="text/javascript" src="LightYear/js/axios.min.js"></script>
    <script type="text/javascript" src="LightYear/js/element.js"></script>
    <script type="text/javascript" src="LightYear/js/index.js"></script>
</body>

</html>