1.上传到网站根目录
2.配置config.php文件
3.访问 域名/xmcking