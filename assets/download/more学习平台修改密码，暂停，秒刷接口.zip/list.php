
//下面是list.php中三个按钮  cid==355意思是仅显示在cid为355的课程，其余的项目就不显示(下面同理)：

<button @click="ms(ddinfo3.info.oid)" v-if="ddinfo3.info.cid == 355 || ddinfo3.info.cid == 397 || ddinfo3.info.cid == 353" class="btn btn-xs btn-danger">秒刷</button>&nbsp; 
<button v-if="ddinfo3.info.cid == 355 || ddinfo3.info.cid == 397 || ddinfo3.info.cid == 353" @click="xgmm(ddinfo3.info.oid)" class="btn btn-xs btn-info">修改密码</button>&nbsp;
<button v-if="ddinfo3.info.cid == 355 || ddinfo3.info.cid == 397 || ddinfo3.info.cid == 353"  @click="zt(ddinfo3.info.oid)" class="btn btn-xs btn-vibrant-blue">暂停</button>

//接口的js，不要乱放，不懂的问老板

xgmm:function (oid) {
    layer.prompt(
        { title: "修改密码", formType: 3 },
        function (xgmm, index) {
            layer.close(index);
            var load = layer.load();
            $.get("/apisb.php?act=xgmm&oid="+oid, { xgmm }, function (data) {
                layer.close(load);
                if (data.code == 1) {
                     
    						vm.get(vm.row.current_page);
    						layer.msg(data.msg, {icon: 1});
                } else {
                    layer.msg(data.msg, { icon: 2 });
                }
            });
        }
    );
},ms:function(oid){
			 	layer.confirm('提交秒刷将扣除0.05元服务费', {title:'温馨提示',icon:3,
								  btn: ['确定','取消'] //按钮
								}, function(){
			 			     var load=layer.load();
			          $.get("/apisb.php?act=ms_order&oid="+oid,function (data) {
					 	     layer.close(load);
				             if (data.code==1){
				             	  vm.get(vm.row.current_page);		             	 
				                layer.alert(data.msg,{icon:1});	                
				             }else{
				                layer.msg(data.msg,{icon:2});
				             }	              
			         });
	         });		
		 },
		 zt:function(oid){
				var load=layer.load();
				layer.msg("正在暂停中....",{icon:3});
          $.get("/apisb.php?act=zt&oid="+oid,function (data) {
		 	     layer.close(load);
	             if (data.code==1){
	             	  vm.get(vm.row.current_page);  
	             	  setTimeout(function() {
	             	  	for(i=0;i<vm.row.data.length;i++){           	
					            	 if(vm.row.data[i].oid==oid){
					            	 	  vm.ddinfo3.info=vm.row.data[i];
					            	 	  console.log(vm.row.data[i].oid);
					            	 	  console.log(vm.row.data[i].status);
					            	 	  console.log(vm.ddinfo3.info.status);
					            	 	  return true;
					            	 } 
					            } 
	             	  },1800);   	             	  		             	 
	                layer.msg(data.msg,{icon:1});	                               
	             }else{
	              	layer.msg(data.msg,{icon:2});	
	             }	              
         });			
		 },