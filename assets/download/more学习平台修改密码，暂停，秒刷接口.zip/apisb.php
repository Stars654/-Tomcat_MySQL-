case 'ms_order'://列表提交秒刷
       $oid=trim(strip_tags(daddslashes($_GET['oid'])));
       $b = $DB->get_row("select cid,dockstatus from qingka_wangke_order where oid='{$oid}' ");
       if ($b['dockstatus'] == '99') {
			jsonReturn(1, "我的订单");
		} else {
			$b = msWk($oid);
			if ($b['code'] == 1) {
              $DB->query("update qingka_wangke_user set money=money-0.05 where uid='{$userrow['uid']}' limit 1 ");
				wlog($userrow['uid'], "提交秒刷", "订单{$oid}提交秒刷成功扣除0.05", -0.05);
				jsonReturn(1, $b['msg']);
			} else {
				jsonReturn(-1, $b['msg']);
			}
		}
    break;
    case 'xgmm':
    $xgmm = trim(strip_tags(daddslashes($_GET['xgmm'])));
    $oid = $_GET['oid']; 
        if (empty($xgmm)) {
        jsonReturn(-1, "密码不能为空");
    }
        if (strlen($xgmm) < 3) {
        jsonReturn(-1, "密码长度至少为3位");
    }   else {
			$b = xgmm($oid,$xgmm);
			if ($b['code'] == 1) {
              
              $DB->query("UPDATE qingka_wangke_order SET pass = '{$xgmm}' WHERE oid = '{$oid}'");
              $DB->query("update qingka_wangke_user set money=money-0.01 where uid='{$userrow['uid']}' limit 1 ");
				wlog($userrow['uid'], "修改密码", "订单{$oid}修改密码成功扣除0.01", -0.01);
				jsonReturn(1, $b['msg']);
			} else {
				jsonReturn(-1, $b['msg']);
			}
		}
    break;
    case 'zt':
		$oid = trim(strip_tags(daddslashes($_GET['oid'])));
		$b = $DB->get_row("select hid,cid,dockstatus from qingka_wangke_order where oid='{$oid}' ");
		$DB->query("update qingka_wangke_order set status='已停止',`bsnum`=bsnum+1 where oid='{$oid}' ");
		if ($b['dockstatus'] == '99') {
			jsonReturn(1, "我的订单");
		} else {
			$b = ztWk($oid);
			if ($b['code'] == 1) {
				$DB->query("update qingka_wangke_order set status='已停止',`bsnum`=bsnum+1 where oid='{$oid}' ");
				wlog($userrow['uid'], "暂停", "暂停订单: {$oid}", 0);
				jsonReturn(1, $b['msg']);
			} else {
				jsonReturn(-1, $b['msg']);
			}
		}
		break;